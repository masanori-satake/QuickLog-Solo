import {
    initDB, dbGet, dbGetAll, dbPut, dbAdd, dbDelete, dbClear,
    STORE_LOGS, STORE_CATEGORIES, STORE_SETTINGS,
    SETTING_KEY_THEME, SETTING_KEY_FONT, SETTING_KEY_ANIMATION
} from './db.js';
import { formatDuration, getAnimationState, startTaskLogic, stopTaskLogic, pauseTaskLogic } from './logic.js';
import { escapeHtml, escapeCsv, parseCsvLine, isValidCategoryName, SYSTEM_CATEGORY_IDLE } from './utils.js';

// QuickLog-Solo: Main Application Entry

// Constants
const THEME_SYSTEM = 'system';

const URL_PARAM_TEST_CAT = 'test_cat';
const URL_PARAM_TEST_ELAPSED = 'test_elapsed';
const URL_PARAM_TEST_RESUMABLE = 'test_resumable';

const MAX_LOGS_DISPLAY = 100;
const TOAST_DURATION_MS = 2000;
const ITEMS_PER_PAGE = 16;

const CSV_HEADER = "id,category,startTime,endTime\n";

const ID_SETTINGS_POPUP = 'settings-popup';
const ID_SETTINGS_TOGGLE = 'settings-toggle';
const ID_THEME_SELECT = 'theme-select';
const ID_FONT_SELECT = 'font-select';
const ID_ANIMATION_SELECT = 'animation-select';
const ID_CATEGORY_LIST = 'category-list';
const ID_CATEGORY_PAGINATION = 'category-pagination';
const ID_LOG_LIST = 'log-list';
const ID_ELAPSED_TIME = 'elapsed-time';
const ID_ELAPSED_TIME_OVERLAY = 'elapsed-time-overlay';
const ID_STATUS_LABEL = 'status-label';
const ID_STATUS_LABEL_OVERLAY = 'status-label-overlay';
const ID_CURRENT_TASK_NAME = 'current-task-name';
const ID_CURRENT_TASK_NAME_OVERLAY = 'current-task-name-overlay';
const ID_PAUSE_BTN = 'pause-btn';
const ID_END_BTN = 'end-btn';
const ID_CURRENT_TASK_DISPLAY = 'current-task-display';
const ID_CURRENT_TASK_DISPLAY_OVERLAY = 'current-task-display-overlay';
const ID_CLOCK_CONTAINER = 'clock-container';
const ID_CLOCK_HAND = 'clock-hand';
const ID_TOAST = 'toast';
const ID_CONFIRM_MODAL = 'confirm-modal';
const ID_CONFIRM_MESSAGE = 'confirm-message';
const ID_CONFIRM_OK_BTN = 'confirm-ok-btn';
const ID_CONFIRM_CANCEL_BTN = 'confirm-cancel-btn';
const ID_VERSION_DISPLAY = 'version-display';
const ID_CATEGORY_EDITOR_LIST = 'category-editor-list';
const ID_NEW_CATEGORY_NAME_SETTINGS = 'new-category-name-settings';
const ID_COPY_REPORT_BTN = 'copy-report-btn';
const ID_COPY_AGGREGATION_BTN = 'copy-aggregation-btn';
const ID_CATEGORY_SECTION = 'category-section';
const ID_ADD_CATEGORY_BTN_SETTINGS = 'add-category-btn-settings';
const ID_EXPORT_CSV_BTN = 'export-csv-btn';
const ID_IMPORT_CSV_BTN = 'import-csv-btn';
const ID_CSV_FILE_INPUT = 'csv-file-input';
const ID_CLEAR_LOGS_BTN = 'clear-logs-btn';
const ID_RESET_CAT_SETTINGS_BTN = 'reset-cat-settings-btn';
const ID_RESET_SETTINGS_BTN = 'reset-settings-btn';

let activeTask = null;
let timerInterval = null;
let currentCategoryPage = 0;
let currentAnimationType = 'left-to-right';

const getEl = (id) => document.getElementById(id);
const queryAll = (selector) => document.querySelectorAll(selector);
const getBody = () => document.body;
const createEl = (tag) => document.createElement(tag);

const FONTS = [
    { name: 'Roboto / Noto Sans JP', value: "'Roboto', 'Noto Sans JP', sans-serif" },
    { name: 'Inter', value: "'Inter', sans-serif" },
    { name: 'Montserrat', value: "'Montserrat', sans-serif" },
    { name: 'Open Sans', value: "'Open Sans', sans-serif" },
    { name: 'Ubuntu', value: "'Ubuntu', sans-serif" },
    { name: 'System Default', value: 'system-ui, -apple-system, sans-serif' }
];

// --- Task Control ---

async function startTask(categoryName, resumableCategory = null) {
    const cat = await dbGet(STORE_CATEGORIES, categoryName);
    const color = cat ? cat.color : null;
    activeTask = await startTaskLogic(categoryName, activeTask, resumableCategory, color);
    updateUI();
}

async function pauseTask() {
    activeTask = await pauseTaskLogic(activeTask);
    updateUI();
}

async function stopTask() {
    activeTask = await stopTaskLogic(activeTask, true);
}

async function endTask() {
    if (!activeTask) return;
    if (await showConfirm('本当に作業を終了しますか？')) {
        await stopTask();
        updateUI();
    }
}

// --- Timer Management ---

function startTimer() {
    if (timerInterval) clearInterval(timerInterval);
    updateTimer();
    timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    if (!activeTask) {
        if (timerInterval) clearInterval(timerInterval);
        return;
    }

    const elapsed = Date.now() - activeTask.startTime;
    const timeStr = formatDuration(elapsed).toString();

    const elements = [ID_ELAPSED_TIME, ID_ELAPSED_TIME_OVERLAY];
    elements.forEach(id => {
        const el = getEl(id);
        if (el) el.textContent = timeStr;
    });

    const isPaused = activeTask.category === SYSTEM_CATEGORY_IDLE;

    const overlay = getEl(ID_CURRENT_TASK_DISPLAY_OVERLAY);
    const clockHand = getEl(ID_CLOCK_HAND);

    if (isPaused) {
        if (overlay) overlay.style.clipPath = 'inset(0 100% 0 0)';
    } else {
        const anim = getAnimationState(activeTask.startTime, currentAnimationType);
        if (currentAnimationType === 'clock') {
            if (overlay) overlay.style.clipPath = 'inset(0 100% 0 0)';
            const clockFace = getEl('clock-face');
            if (clockFace) {
                const activeColor = 'var(--custom-cat-on-main)';
                const bgColor = 'transparent';
                if (!anim.isPhase2) {
                    clockFace.style.background = `conic-gradient(${activeColor} 0deg ${anim.angle}deg, ${bgColor} ${anim.angle}deg 360deg)`;
                } else {
                    clockFace.style.background = `conic-gradient(${bgColor} 0deg ${anim.angle}deg, ${activeColor} ${anim.angle}deg 360deg)`;
                }
            }
        } else {
            if (overlay) overlay.style.clipPath = anim.inset;
        }
    }
}

// --- UI Rendering ---

function applyTheme(theme) {
    const body = getBody();
    body.classList.remove('theme-light', 'theme-dark');
    if (theme === THEME_SYSTEM) {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        body.classList.add(isDark ? 'theme-dark' : 'theme-light');
    } else {
        body.classList.add(`theme-${theme}`);
    }
    const select = getEl(ID_THEME_SELECT);
    if (select) select.value = theme;
}


function applyFont(fontValue) {
    getBody().style.setProperty('--font-family', fontValue);
    const select = getEl(ID_FONT_SELECT);
    if (select) select.value = fontValue;
}

function applyAnimation(animationType) {
    currentAnimationType = animationType;
    const select = getEl(ID_ANIMATION_SELECT);
    if (select) select.value = animationType;

    const clockContainer = getEl(ID_CLOCK_CONTAINER);
    const overlay = getEl(ID_CURRENT_TASK_DISPLAY_OVERLAY);

    if (animationType === 'clock') {
        clockContainer?.classList.remove('hidden');
        if (overlay) overlay.style.clipPath = 'inset(0 100% 0 0)';
    } else {
        clockContainer?.classList.add('hidden');
    }
}

async function renderCategories() {
    console.log('QuickLog-Solo: Rendering categories...');
    let categories;
    try {
        categories = await dbGetAll(STORE_CATEGORIES);
    } catch (e) {
        console.error('Failed to get categories:', e);
        return;
    }
    categories.sort((a, b) => (a.order || 0) - (b.order || 0));

    const totalPages = Math.ceil(categories.length / ITEMS_PER_PAGE) || 1;
    if (currentCategoryPage >= totalPages) currentCategoryPage = totalPages - 1;

    const start = currentCategoryPage * ITEMS_PER_PAGE;
    const pageCategories = categories.slice(start, start + ITEMS_PER_PAGE);

    const list = getEl(ID_CATEGORY_LIST);
    if (!list) return;
    list.innerHTML = '';

    pageCategories.forEach(cat => {
        const btn = createEl('button');
        btn.className = `category-btn cat-${cat.color || 'primary'}`;
        const isActive = activeTask && activeTask.category === cat.name;
        if (isActive) {
            btn.classList.add('active');
            btn.disabled = true;
        }
        btn.textContent = cat.name;
        btn.title = cat.name;
        btn.onclick = () => startTask(cat.name);
        list.appendChild(btn);
    });

    renderPaginationDots(totalPages);
}

function renderPaginationDots(totalPages) {
    const container = getEl(ID_CATEGORY_PAGINATION);
    if (!container) return;
    container.innerHTML = '';

    for (let i = 0; i < totalPages; i++) {
        const dot = createEl('div');
        dot.className = 'pagination-dot' + (i === currentCategoryPage ? ' active' : '');
        container.appendChild(dot);
    }
}

async function renderLogs() {
    let allLogs;
    let categories;
    try {
        allLogs = await dbGetAll(STORE_LOGS);
        categories = await dbGetAll(STORE_CATEGORIES);
    } catch (e) {
        console.error('Failed to get data for logs:', e);
        return;
    }
    const categoryMap = new Map(categories.map(c => [c.name, c]));
    const visibleLogs = allLogs.sort((a, b) => b.startTime - a.startTime).slice(0, MAX_LOGS_DISPLAY);

    const logList = getEl(ID_LOG_LIST);
    if (!logList) return;
    logList.innerHTML = '';

    let lastDate = '';
    const days = ['日', '月', '火', '水', '木', '金', '土'];

    visibleLogs.forEach((log) => {
        const d = new Date(log.startTime);
        const dateStr = `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')} (${days[d.getDay()]})`;

        if (dateStr !== lastDate) {
            const header = createEl('li');
            header.className = 'log-date-header';
            header.textContent = dateStr;
            logList.appendChild(header);
            lastDate = dateStr;
        }

        const li = createLogElement(log, categoryMap);
        logList.appendChild(li);
    });
}

function createLogElement(log, categoryMap) {
    const li = createEl('li');
    li.className = 'log-item';
    const startTimeStr = new Date(log.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const endTimeStr = log.endTime ? new Date(log.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

    let timeRangeHtml;
    if (log.isManualStop) {
        timeRangeHtml = `<span class="log-time"><span style="visibility:hidden">${startTimeStr}</span>-${endTimeStr}</span>`;
    } else if (log.endTime) {
        timeRangeHtml = `<span class="log-time">${startTimeStr}-${endTimeStr}</span>`;
    } else {
        timeRangeHtml = `<span class="log-time">${startTimeStr}-<span style="visibility:hidden">${startTimeStr}</span></span>`;
    }

    const durationMs = log.endTime ? log.endTime - log.startTime : 0;
    let durationText = '';
    if (log.endTime && !log.isManualStop) {
        durationText = durationMs < 60000 ? `${Math.round(durationMs / 1000)}s` : `${Math.round(durationMs / 60000)}m`;
    }

    let colorClass = 'dot-gray';
    let displayName = log.category;

    if (log.isManualStop) {
        colorClass = 'dot-error';
        displayName = '終了';
    } else if (log.category === SYSTEM_CATEGORY_IDLE) {
        colorClass = 'dot-neutral';
    } else {
        const color = log.color || (categoryMap.get(log.category) ? categoryMap.get(log.category).color : 'primary');
        colorClass = `dot-${color}`;
    }

    li.innerHTML = `
        ${timeRangeHtml}
        <span class="log-name"><span class="category-dot ${colorClass}"></span>${escapeHtml(displayName)}</span>
        <span class="log-duration">${durationText}</span>
    `;
    return li;
}

async function updateUI() {
    console.log('QuickLog-Solo: updateUI called');
    if (timerInterval) clearInterval(timerInterval);

    try {
        await renderCategories();
    } catch (e) {
        console.error('updateUI: Failed to render categories', e);
    }

    try {
        await renderLogs();
    } catch (e) {
        console.error('updateUI: Failed to render logs', e);
    }

    const elements = {
        statusLabel: getEl(ID_STATUS_LABEL),
        statusLabelOverlay: getEl(ID_STATUS_LABEL_OVERLAY),
        currentTaskName: getEl(ID_CURRENT_TASK_NAME),
        currentTaskNameOverlay: getEl(ID_CURRENT_TASK_NAME_OVERLAY),
        pauseBtn: getEl(ID_PAUSE_BTN),
        endBtn: getEl(ID_END_BTN),
        elapsedTime: getEl(ID_ELAPSED_TIME),
        elapsedTimeOverlay: getEl(ID_ELAPSED_TIME_OVERLAY),
        display: getEl(ID_CURRENT_TASK_DISPLAY),
        overlay: getEl(ID_CURRENT_TASK_DISPLAY_OVERLAY)
    };

    if (activeTask) {
        let color = 'primary';
        const isPaused = activeTask.category === SYSTEM_CATEGORY_IDLE;

        // Ensure proper animation/clock visibility
        applyAnimation(currentAnimationType);

        if (isPaused) {
            color = 'neutral';
        } else {
            const cat = await dbGet(STORE_CATEGORIES, activeTask.category);
            color = cat ? cat.color : (activeTask.color || 'primary');
        }

        if (elements.display) elements.display.className = `cat-${color}`;
        if (elements.overlay) elements.overlay.className = `cat-${color}-full`;

        const iconName = isPaused ? 'pause' : 'play_arrow';
        const statusClass = isPaused ? 'status-paused' : 'status-running';
        [elements.statusLabel, elements.statusLabelOverlay].forEach(el => {
            if (el) {
                el.textContent = iconName;
                el.className = `material-symbols-outlined ${statusClass}`;
                if (isPaused) {
                    el.classList.add('blink');
                } else {
                    el.classList.remove('blink');
                }
            }
        });
        [elements.currentTaskName, elements.currentTaskNameOverlay].forEach(el => { if (el) el.textContent = activeTask.category; });

        if (elements.pauseBtn) {
            if (isPaused) {
                elements.pauseBtn.innerHTML = '<span class="material-symbols-outlined btn-icon">play_arrow</span><span class="btn-text">再開</span>';
                elements.pauseBtn.disabled = !activeTask.resumableCategory;
            } else {
                elements.pauseBtn.innerHTML = '<span class="material-symbols-outlined btn-icon">pause</span><span class="btn-text">一時停止</span>';
                elements.pauseBtn.disabled = false;
            }
        }
        if (elements.endBtn) elements.endBtn.disabled = false;

        [elements.elapsedTime, elements.elapsedTimeOverlay].forEach(el => {
            if (el) {
                el.classList.remove('hidden');
                el.style.visibility = isPaused ? 'hidden' : 'visible';
            }
        });
        startTimer();
    } else {
        if (elements.display) elements.display.className = '';
        if (elements.overlay) elements.overlay.className = '';
        [elements.statusLabel, elements.statusLabelOverlay].forEach(el => {
            if (el) {
                el.textContent = 'stop';
                el.className = 'material-symbols-outlined status-stopped';
            }
        });
        [elements.currentTaskName, elements.currentTaskNameOverlay].forEach(el => { if (el) el.textContent = '-'; });

        if (elements.pauseBtn) {
            elements.pauseBtn.disabled = true;
            elements.pauseBtn.innerHTML = '<span class="material-symbols-outlined btn-icon">pause</span><span class="btn-text">一時停止</span>';
        }
        if (elements.endBtn) elements.endBtn.disabled = true;

        [elements.elapsedTime, elements.elapsedTimeOverlay].forEach(el => {
            if (el) {
                el.classList.add('hidden');
                el.textContent = '00:00:00';
                el.style.visibility = 'visible';
            }
        });
        if (elements.overlay) elements.overlay.style.clipPath = 'inset(0 0 0 100%)';
        document.title = 'QuickLog-Solo';
    }
}

// --- Action Logic ---

async function copyReport() {
    const allLogs = await dbGetAll(STORE_LOGS);
    const today = new Date().setHours(0,0,0,0);
    const todayLogs = allLogs.filter(l => l.startTime >= today && l.endTime);

    let text = "";
    todayLogs.forEach(l => {
        const start = new Date(l.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        text += `${start} | ${l.category}\n`;
    });

    navigator.clipboard.writeText(text);
    showToast('コピーしました！');
}

async function copyAggregation() {
    const allLogs = await dbGetAll(STORE_LOGS);
    const today = new Date().setHours(0,0,0,0);
    const todayLogs = allLogs.filter(l => l.startTime >= today && l.endTime);

    const agg = {};
    todayLogs.forEach(l => {
        const dur = (l.endTime - l.startTime) / 60000;
        agg[l.category] = (agg[l.category] || 0) + dur;
    });

    let text = "";
    for (const cat in agg) {
        text += `${cat} | ${Math.round(agg[cat])} min\n`;
    }

    navigator.clipboard.writeText(text);
    showToast('コピーしました！');
}

function showToast(message = "完了しました！") {
    const toast = getEl(ID_TOAST);
    if (toast) {
        toast.innerText = message;
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), TOAST_DURATION_MS);
    }
}

function showConfirm(message) {
    return new Promise((resolve) => {
        const modal = getEl(ID_CONFIRM_MODAL);
        const msgEl = getEl(ID_CONFIRM_MESSAGE);
        const okBtn = getEl(ID_CONFIRM_OK_BTN);
        const cancelBtn = getEl(ID_CONFIRM_CANCEL_BTN);

        if (!modal || !msgEl || !okBtn || !cancelBtn) {
            resolve(confirm(message));
            return;
        }

        msgEl.innerText = message;
        modal.classList.remove('hidden');

        const cleanup = (result) => {
            modal.classList.add('hidden');
            okBtn.onclick = null;
            cancelBtn.onclick = null;
            resolve(result);
        };

        okBtn.onclick = () => cleanup(true);
        cancelBtn.onclick = () => cleanup(false);
    });
}

// --- Category Editor ---

function getColorCode(color) {
    // These are fallback codes for the editor, matching the refined palette in css/m3-theme.css.
    const codes = {
        primary: '#1976d2',
        secondary: '#7cb342',
        tertiary: '#8e24aa',
        error: '#d32f2f',
        neutral: '#546e7a',
        outline: '#9e9e9e',
        teal: '#0097a7',
        green: '#388e3c',
        yellow: '#fbc02d',
        orange: '#ffa000',
        pink: '#d81b60',
        indigo: '#5e35b1',
        brown: '#6d4c41',
        cyan: '#039be5'
    };
    return codes[color] || '#333';
}

async function renderCategoryEditor() {
    const list = getEl(ID_CATEGORY_EDITOR_LIST);
    if (!list) return;
    let categories = await dbGetAll(STORE_CATEGORIES);
    categories = categories.filter(c => c.name !== SYSTEM_CATEGORY_IDLE).sort((a, b) => a.order - b.order);
    list.innerHTML = '';

    categories.forEach(cat => {
        const item = createEl('div');
        item.className = 'category-editor-item';
        item.draggable = true;
        item.dataset.name = cat.name;

        const colors = [
            'primary', 'secondary', 'tertiary', 'error', 'neutral', 'outline',
            'teal', 'green', 'yellow', 'orange', 'pink', 'indigo', 'brown', 'cyan'
        ];
        const colorPresetsHtml = colors.map(color => `
            <button class="color-preset ${color === cat.color ? 'selected' : ''}"
                    style="background-color: ${getColorCode(color)}"
                    data-color="${color}"></button>
        `).join('');

        item.innerHTML = `
            <div class="cat-editor-row">
                <span class="material-symbols-outlined drag-handle" style="cursor: grab;">drag_indicator</span>
                <input type="text" class="category-edit-name" value="${escapeHtml(cat.name)}">
                <button class="delete-cat-btn" title="削除" style="border:none; background:none; padding:0; display:flex; align-items:center; justify-content:center;">
                    <span class="material-symbols-outlined">delete</span>
                </button>
            </div>
            <div class="cat-editor-row" style="margin-top: 0.5rem;">
                <div class="color-presets" style="margin-left: 2rem;">
                    ${colorPresetsHtml}
                </div>
            </div>
        `;

        // Event listeners
        const input = item.querySelector('.category-edit-name');
        input.onchange = async () => {
            const newName = input.value.trim();
            if (newName && newName !== cat.name) {
                if (!isValidCategoryName(newName)) {
                    alert(`無効なカテゴリ名です。（50文字以内、「${SYSTEM_CATEGORY_IDLE}」は使用不可）`);
                    input.value = cat.name;
                    return;
                }
                const oldName = cat.name;
                const existing = await dbGet(STORE_CATEGORIES, newName);
                if (existing) {
                    alert('同名のカテゴリが既に存在します。');
                    input.value = oldName;
                    return;
                }
                const updatedCat = { ...cat, name: newName };
                await dbDelete(STORE_CATEGORIES, oldName);
                await dbPut(STORE_CATEGORIES, updatedCat);

                const allLogs = await dbGetAll(STORE_LOGS);
                for (const log of allLogs) {
                    if (log.category === oldName) {
                        log.category = newName;
                        await dbPut(STORE_LOGS, log);
                    }
                }
                updateUI();
                renderCategoryEditor();
            }
        };

        item.querySelectorAll('.color-preset').forEach(btn => {
            btn.onclick = async () => {
                cat.color = btn.dataset.color;
                await dbPut(STORE_CATEGORIES, cat);
                renderCategoryEditor();
                renderCategories();
            };
        });

        item.querySelector('.delete-cat-btn').onclick = async () => {
            if (await showConfirm(`カテゴリ「${cat.name}」を削除しますか？\n（過去のログからはカテゴリ色が消えます）`)) {
                await dbDelete(STORE_CATEGORIES, cat.name);
                updateUI();
                renderCategoryEditor();
            }
        };

        item.ondragstart = (e) => {
            e.dataTransfer.setData('text/plain', cat.name);
            item.classList.add('dragging');
        };
        item.ondragend = () => item.classList.remove('dragging');

        list.appendChild(item);
    });

    list.ondragover = (e) => {
        e.preventDefault();
        const draggingItem = list.querySelector('.dragging');
        if (!draggingItem) return;
        const siblings = [...list.querySelectorAll('.category-editor-item:not(.dragging)')];
        let nextSibling = siblings.find(sibling => {
            return e.clientY <= sibling.getBoundingClientRect().top + sibling.getBoundingClientRect().height / 2;
        });
        list.insertBefore(draggingItem, nextSibling);
    };

    list.ondrop = async (e) => {
        e.preventDefault();
        const items = [...list.querySelectorAll('.category-editor-item')];
        for (let i = 0; i < items.length; i++) {
            const name = items[i].dataset.name;
            const cat = await dbGet(STORE_CATEGORIES, name);
            if (cat) {
                cat.order = i;
                await dbPut(STORE_CATEGORIES, cat);
            }
        }
        renderCategories();
        renderCategoryEditor();
    };
}

// --- Initialization & Event Listeners ---

async function loadVersion() {
    try {
        const response = await fetch('version.json');
        const data = await response.json();
        const el = getEl(ID_VERSION_DISPLAY);
        if (el) el.textContent = `v${data.version}`;
    } catch (e) {
        console.error('Failed to load version:', e);
    }
}

function setupEventListeners() {
    getEl(ID_PAUSE_BTN)?.addEventListener('click', () => {
        if (!activeTask) return;
        if (activeTask.category === SYSTEM_CATEGORY_IDLE) {
            startTask(activeTask.resumableCategory);
        } else {
            pauseTask();
        }
    });
    getEl(ID_END_BTN)?.addEventListener('click', endTask);
    getEl(ID_COPY_REPORT_BTN)?.addEventListener('click', copyReport);
    getEl(ID_COPY_AGGREGATION_BTN)?.addEventListener('click', copyAggregation);

    // Category Wheel Pagination
    const categorySection = getEl(ID_CATEGORY_SECTION);
    categorySection?.addEventListener('wheel', (e) => {
        e.preventDefault();
        dbGetAll(STORE_CATEGORIES).then(categories => {
            const totalPages = Math.ceil(categories.length / ITEMS_PER_PAGE) || 1;
            if (e.deltaY > 0) {
                // Scroll down -> next page
                if (currentCategoryPage < totalPages - 1) {
                    currentCategoryPage++;
                    renderCategories();
                }
            } else {
                // Scroll up -> prev page
                if (currentCategoryPage > 0) {
                    currentCategoryPage--;
                    renderCategories();
                }
            }
        });
    }, { passive: false });

    // Modals
    const popups = {
        settings: getEl(ID_SETTINGS_POPUP)
    };

    getEl(ID_SETTINGS_TOGGLE)?.addEventListener('click', () => popups.settings?.classList.remove('hidden'));

    queryAll('.close-btn').forEach(btn => {
        btn.onclick = () => Object.values(popups).forEach(p => p?.classList.add('hidden'));
    });

    window.onclick = (event) => {
        Object.values(popups).forEach(p => { if (event.target === p) p.classList.add('hidden'); });
    };

    // Tabs
    queryAll('.tab-btn').forEach(btn => {
        btn.onclick = () => {
            queryAll('.tab-btn').forEach(b => b.classList.remove('active'));
            queryAll('.tab-content').forEach(c => c.classList.add('hidden'));
            btn.classList.add('active');
            const target = getEl(`${btn.dataset.tab}-tab`);
            if (target) target.classList.remove('hidden');
            if (btn.dataset.tab === 'categories') renderCategoryEditor();
        };
    });

    // Settings listeners
    getEl(ID_THEME_SELECT)?.addEventListener('change', async (e) => {
        const theme = e.target.value;
        await dbPut(STORE_SETTINGS, { key: SETTING_KEY_THEME, value: theme });
        applyTheme(theme);
    });


    const fontSelect = getEl(ID_FONT_SELECT);
    if (fontSelect) {
        FONTS.forEach(f => {
            const opt = createEl('option');
            opt.value = f.value;
            opt.textContent = f.name;
            opt.style.fontFamily = f.value;
            fontSelect.appendChild(opt);
        });
        fontSelect.onchange = async (e) => {
            const fontValue = e.target.value;
            await dbPut(STORE_SETTINGS, { key: SETTING_KEY_FONT, value: fontValue });
            applyFont(fontValue);
        };
    }

    const animSelect = getEl(ID_ANIMATION_SELECT);
    if (animSelect) {
        animSelect.onchange = async (e) => {
            const animType = e.target.value;
            await dbPut(STORE_SETTINGS, { key: SETTING_KEY_ANIMATION, value: animType });
            applyAnimation(animType);
        };
    }

    // Category additions
    getEl(ID_ADD_CATEGORY_BTN_SETTINGS)?.addEventListener('click', async () => {
        const input = getEl(ID_NEW_CATEGORY_NAME_SETTINGS);
        const name = input?.value.trim();
        if (name) {
            if (!isValidCategoryName(name)) {
                alert(`無効なカテゴリ名です。（50文字以内、「${SYSTEM_CATEGORY_IDLE}」は使用不可）`);
                return;
            }
            const categories = await dbGetAll(STORE_CATEGORIES);
            await dbPut(STORE_CATEGORIES, { name, color: 'primary', order: categories.length });
            if (input) input.value = '';
            renderCategories();
            renderCategoryEditor();
        }
    });

    // CSV and Maintenance helpers
    async function performMaintenanceAction(confirmMessage, action) {
        if (await showConfirm(confirmMessage)) {
            if (activeTask) {
                await stopTask();
                updateUI();
            }
            await action();
        }
    }

    getEl(ID_EXPORT_CSV_BTN)?.addEventListener('click', () => {
        performMaintenanceAction('ログデータをCSVとして書き出します。実行中の作業がある場合は終了されます。よろしいですか？', async () => {
            const logs = await dbGetAll(STORE_LOGS);
            let csv = CSV_HEADER;
            logs.forEach(l => { csv += `${l.id},${escapeCsv(l.category)},${l.startTime},${l.endTime}\n`; });
            const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
            const a = createEl('a');
            a.href = url;
            a.download = `quicklog_backup_${new Date().toISOString().slice(0,10)}.csv`;
            a.click();
        });
    });

    const csvInput = getEl(ID_CSV_FILE_INPUT);
    getEl(ID_IMPORT_CSV_BTN)?.addEventListener('click', () => {
        performMaintenanceAction('CSVファイルからログデータを読み込みます。既存のデータに追記されます。実行中の作業がある場合は終了されます。よろしいですか？', async () => {
            csvInput?.click();
        });
    });

    csvInput?.addEventListener('change', async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const text = await file.text();
        const lines = text.split(/\r?\n/).filter(line => line.trim() !== '').slice(1);
        for (const line of lines) {
            const parts = parseCsvLine(line);
            if (parts.length >= 3) {
                const [, category, startTime, endTime] = parts;
                if (category && startTime) {
                    await dbPut(STORE_LOGS, {
                        category,
                        startTime: parseInt(startTime),
                        endTime: endTime ? parseInt(endTime) : null
                    });
                }
            }
        }
        updateUI();
        alert('インポートが完了しました。');
    });

    getEl(ID_CLEAR_LOGS_BTN)?.addEventListener('click', () => {
        performMaintenanceAction('全てのログを削除します。実行中の作業がある場合は終了されます。よろしいですか？', async () => {
            await dbClear(STORE_LOGS);
            updateUI();
            showToast('削除が完了しました');
        });
    });

    getEl(ID_RESET_CAT_SETTINGS_BTN)?.addEventListener('click', () => {
        performMaintenanceAction('カテゴリと各種設定を初期化します。実行中の作業がある場合は終了されます。よろしいですか？（ログは維持されます）', async () => {
            await dbClear(STORE_CATEGORIES);
            await dbClear(STORE_SETTINGS);
            location.reload();
        });
    });

    getEl(ID_RESET_SETTINGS_BTN)?.addEventListener('click', () => {
        performMaintenanceAction('各種設定を初期化します。実行中の作業がある場合は終了されます。よろしいですか？（ログとカテゴリは維持されます）', async () => {
            await dbClear(STORE_SETTINGS);
            location.reload();
        });
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    console.log('QuickLog-Solo: DOMContentLoaded');
    try {
        await loadVersion();
    } catch (e) {
        console.error('Failed to load version:', e);
    }

    try {
        console.log('QuickLog-Solo: Initializing DB...');
        const settings = await initDB();
        console.log('QuickLog-Solo: DB Initialized', settings);
        activeTask = settings.activeTask;

        applyTheme(settings.theme || THEME_SYSTEM);
        applyFont(settings.font || FONTS[0].value);
        applyAnimation(settings.animation || 'left-to-right');

        setupEventListeners();
        await handleTestParameters();
        await updateUI();
    } catch (e) {
        console.error('Failed to initialize application:', e);
        alert('アプリの初期化に失敗しました。ページを再読み込みしてください。');
    }

    console.log('QuickLog-Solo Initialized');
});

async function handleTestParameters() {
    const urlParams = new URLSearchParams(window.location.search);

    // テスト用のタスク開始: ?test_cat=Dev&test_elapsed=60000&test_resumable=Dev
    let testCat = urlParams.get(URL_PARAM_TEST_CAT);
    if (testCat) {
        if (testCat.length > 50) testCat = testCat.substring(0, 50);
        const elapsed = parseInt(urlParams.get(URL_PARAM_TEST_ELAPSED) || '0');
        const resumable = urlParams.get(URL_PARAM_TEST_RESUMABLE);
        const startTime = Date.now() - elapsed;

        // 既存のタスクを強制終了
        if (activeTask) {
            await stopTaskLogic(activeTask);
        }

        // 指定された状態をDBに直接注入
        const newLog = {
            category: testCat,
            startTime: startTime,
            endTime: null,
            resumableCategory: resumable
        };
        const id = await dbAdd(STORE_LOGS, newLog);
        newLog.id = id;
        activeTask = newLog;

        // URLをクリーンアップして再読み込み時にループしないようにする
        const newUrl = window.location.pathname;
        window.history.replaceState({}, '', newUrl);
    }
}
